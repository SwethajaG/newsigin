import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class StudentService {

  url = 'http://localhost:3000/students';
  updateUrl = '';
  studentsLength = 0;

  constructor(private http: HttpClient) { }

  getAllStudents() {
    return this.http.get(this.url);
  }

  createStudent(data: any) {
    return this.http.post(this.url, data);
  }

  getStudentById(id: any) {
    return this.http.get(this.url + '/' + id);
  }

  updateStudent(data: any) {
    this.updateUrl = this.url + '/' + data.id;
    return this.http.put(this.updateUrl, data);
  }

  deleteStudent(id: any) {
    return this.http.delete(this.url + '/' + id);
  }
}
