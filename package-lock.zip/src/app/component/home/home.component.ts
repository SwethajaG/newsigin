import { Component, OnInit, DoCheck } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from '../../services/user.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements DoCheck, OnInit {

  userName: any;
  homeHeading = 'Welcome';
  constructor(private router: Router, private userService: UserService) {
    this.userName = this.userService.userName;
  }

  ngOnInit(): void {

  }

  ngDoCheck(): void {
    if (this.router.url === '/') {
      this.userService.currComp = 'Welcome';
    }
    this.homeHeading = this.userService.currComp;
  }

  logout() {
    this.userService.userName = '';
    this.router.navigate(['/signin']);
  }

}
