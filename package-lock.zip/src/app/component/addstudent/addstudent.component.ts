import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { StudentService } from '../../services/student.service';
import { FormBuilder } from '@angular/forms';
import { Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { UserService } from '../../services/user.service';
import { MatDialog } from '@angular/material/dialog';
import { DialogComponent } from '../../common/dialog/dialog.component';

@Component({
  selector: 'app-addstudent',
  templateUrl: './addstudent.component.html',
  styleUrls: ['./addstudent.component.css']
})
export class AddstudentComponent implements OnInit {

  submitted = false;
  id = 0;
  x: any;
  update = false;
  profileForm = this.fb.group({
    name: ['', Validators.required],
    rollno: ['', Validators.required],
    fathername: ['', Validators.required],
    class: ['', Validators.required],
    mailid: ['', [Validators.required, Validators.email]],
    mobileno: ['', [Validators.required, Validators.pattern('[0-9 ]{12}')]],
    address: [''],
    id: [0]
  });

  errorMessage = '';


  constructor(private studentService: StudentService, private router: Router, private fb: FormBuilder,
    private route: ActivatedRoute, private userService: UserService, public dialog: MatDialog) {
    this.id = this.route.snapshot.params.id;
    if (this.id > 0) {
      this.update = true;
      this.getStudentById(this.id);
    } else {
      this.userService.currComp = 'Add New Student ';
    }
  }

  ngOnInit(): void {

  }

  save() {
    if (this.id === 0 || this.id === null || this.id === undefined) {
      this.saveStudent();
    } else if (this.id > 0) {
      this.updateStudent();
    } else {
      this.clearAll();
    }
  }

  saveStudent() {
    this.submitted = true;
    if (this.profileForm.valid) {
      this.studentService.createStudent(this.profileForm.value).subscribe((data: any) => {
        this.studentService.studentsLength += 1;
        this.userService.msgType = 'addsuccess';
        this.openDialog();
      });
    }
  }

  getStudentById(id: any) {
    this.studentService.getStudentById(id).subscribe((data: any) => {
      this.profileForm.setValue({
        name: data.name,
        rollno: data.rollno,
        fathername: data.fathername,
        class: data.class,
        mailid: data.mailid,
        mobileno: data.mobileno,
        address: data.address,
        id: this.id
      });
      this.userService.currComp = 'Edit Student - ' + this.profileForm.value.name;
    });
  }

  updateStudent() {
    if (this.profileForm.valid) {
      this.studentService.updateStudent(this.profileForm.value).subscribe((data: any) => {
        this.userService.msgType = 'updatesuccess';
        this.openDialog();
      });
    }
  }

  clearAll() {
    this.profileForm.patchValue({
      name: '',
      rollno: '',
      fathername: '',
      class: '',
      mailid: '',
      mobileno: '',
      address: '',
      id: 0
    });
    this.errorMessage = '';
    this.submitted = false;
  }

  get controls() {
    return this.profileForm.controls;
  }

  cancel() {
    this.router.navigate(['/viewstudent']);
  }

  openDialog() {


    const dialogRef = this.dialog.open(DialogComponent);

    dialogRef.afterClosed().subscribe(result => {
      this.clearAll();
      if (this.id > 0) {
        this.router.navigate(['/viewstudent']);
      }
    });


  }

}
