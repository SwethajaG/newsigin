import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from '../../services/user.service';
import { FormBuilder } from '@angular/forms';
import { Validators } from '@angular/forms';

@Component({
  selector: 'app-signin',
  templateUrl: './signin.component.html',
  styleUrls: ['./signin.component.css'],
})
export class SigninComponent implements OnInit {

  profileForm = this.fb.group({
    userName: ['', Validators.required],
    password: ['', Validators.required]
  });
  submitted = false;
  userDetails: any;
  invalid = false;
  errorMessage = '';
  loginedUser: any;
  constructor(private userService: UserService, private router: Router, private fb: FormBuilder) {
    this.getLoginUsers();
  }

  ngOnInit(): void {
  }

  getLoginUsers() {
    this.userService.getAllUsers().subscribe((data: any) => {
      this.userDetails = data;
    });
  }

  checkUser() {
    this.submitted = true;
    if (this.profileForm.valid) {
      this.loginedUser = this.userDetails.find((data: any) => {
        if (data.userName === this.profileForm.value.userName && data.password === this.profileForm.value.password) {
          this.userService.userName = this.profileForm.value.userName;
          this.router.navigate(['']);
        } else {
          this.invalid = true;
        }
      });
    }


  }

  get f() {
    return this.profileForm.controls;
  }

}
