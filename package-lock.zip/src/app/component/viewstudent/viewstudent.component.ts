import { Component, OnInit, ViewChild, AfterViewInit } from '@angular/core';
import { StudentService } from '../../services/student.service';
import { Router } from '@angular/router';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { UserService } from '../../services/user.service';
import { MatDialog } from '@angular/material/dialog';
import { DialogComponent } from '../../common/dialog/dialog.component';

@Component({
  selector: 'app-viewstudent',
  templateUrl: './viewstudent.component.html',
  styleUrls: ['./viewstudent.component.css']
})
export class ViewstudentComponent implements AfterViewInit, OnInit {

  students: any;
  searchTerm = '';
  x: any;
  deleteStudentId = 0;
  length = 0;
  displayedColumns: string[] = ['rollno', 'name', 'class', 'mailid', 'mobileno', 'address', 'edit', 'delete'];
  // tslint:disable-next-line: new-parens
  dataSource = new MatTableDataSource<any>();

  @ViewChild(MatPaginator)
  // tslint:disable-next-line: new-parens
  paginator!: MatPaginator;
  // tslint:disable-next-line: typedef-whitespace
  // tslint:disable-next-line: typedef-whitespace
  // tslint:disable-next-line: typedef-whitespace
  // tslint:disable-next-line: typedef-whitespace
  @ViewChild(MatSort)
  // tslint:disable-next-line: new-parens
  sort: MatSort = new MatSort;

  constructor(private studentService: StudentService, private router: Router, private userService: UserService,
    public dialog: MatDialog) {
    this.userService.currComp = 'View Student';
    this.getAllStudents();
  }

  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  ngOnInit(): void {
  }

  getAllStudents() {
    this.studentService.getAllStudents().subscribe((data: any) => {
      this.students = data;
      this.studentService.studentsLength = data.length;
      this.length = data.length;
      this.dataSource = new MatTableDataSource(this.students);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    });
  }

  editStudent(student: any) {
    this.router.navigate(['/addstudent/' + student.id]);
  }

  deleteStudent() {
    this.studentService.deleteStudent(this.deleteStudentId).subscribe((data: any) => {
      this.getAllStudents();
      this.x.className = '';
    });
  }
  deletemessage(student: any) {
    this.deleteStudentId = student.id;

    this.userService.msgType = 'confirm';
    const dialogRef = this.dialog.open(DialogComponent);

    dialogRef.afterClosed().subscribe(result => {
      if (result) { this.deleteStudent(); }
    });

    // this.x = document.getElementById('snackbar');
    // this.x.className = 'show';
    //setTimeout( () => { this.x.className = this.x.className.replace('show', '');  }, 1000);
  }
  closeToast() {
    this.x.className = '';
  }


  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }
}




