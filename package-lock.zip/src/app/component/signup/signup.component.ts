import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from '../../services/user.service';
import { FormBuilder } from '@angular/forms';
import { Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { DialogComponent } from '../../common/dialog/dialog.component';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {

  submitted = false;
  x: any;

  profileForm = this.fb.group({
    userName: ['', Validators.required],
    firstName: ['', Validators.required],
    lastName: ['', Validators.required],
    password: ['', Validators.required],
    email: ['', [Validators.required, Validators.email]],
    mobileno: ['', [Validators.required, Validators.minLength(10), Validators.maxLength(10)]],
    address: ['']
  });

  errorMessage = '';


  constructor(private userService: UserService, private router: Router, private fb: FormBuilder, public dialog: MatDialog) {
  }

  ngOnInit(): void {
  }

  createNewUser() {
    this.submitted = true;
    if (this.profileForm.valid) {
      this.userService.createuser(this.profileForm.value).subscribe((data: any) => {

        this.openDialog();

      });
    }
  }

  clearAll() {
    this.profileForm.patchValue({
      userName: '',
      firstName: '',
      lastName: '',
      password: '',
      email: '',
      mobileno: '',
      address: ''
    });
    this.submitted = false;
    this.errorMessage = '';
  }

  back() {
    this.router.navigate(['/signin']);
  }

  get controls() {
    return this.profileForm.controls;
  }

  // message() {
  //   this.x  = document.getElementById('snackbar');
  //   this.x.className = 'show';
  //   setTimeout( () => { this.x.className = this.x.className.replace('show', ''); this.back(); }, 1000);
  // }

  openDialog() {

    this.userService.msgType = 'regsuccess';
    const dialogRef = this.dialog.open(DialogComponent);

    dialogRef.afterClosed().subscribe(result => {
      this.clearAll();
      this.router.navigate(['/signin']);
    });


  }
}
