import { Component, OnInit } from '@angular/core';
import { UserService } from '../../services/user.service';

@Component({
  selector: 'app-dialog',
  templateUrl: './dialog.component.html',
  styleUrls: ['./dialog.component.css']
})
export class DialogComponent implements OnInit {

  heading = '';
  message = '';
  msgType = '';
  blnconfirmMsg = false;
  constructor(private userService: UserService) {
    this.msgType = this.userService.msgType;
  }

  ngOnInit(): void {
    switch (this.msgType) {
      case 'addsuccess':
        this.blnconfirmMsg = false;
        this.addSuccessMsg();
        break;
      case 'updatesuccess':
        this.blnconfirmMsg = false;
        this.updateSuccessMsg();
        break;
      case 'regsuccess':
        this.blnconfirmMsg = false;
        this.regSuccessMsg();
        break;
      case 'confirm':
        this.blnconfirmMsg = true;
        this.confirmMsg();
        break;

      default:
        break;
    }
  }

  addSuccessMsg() {
    this.heading = 'Success Message';
    this.message = 'New Student Added Successfully !';
  }

  updateSuccessMsg() {
    this.heading = 'Success Message';
    this.message = 'New Student Updated Successfully !';
  }

  regSuccessMsg() {
    this.heading = 'Success Message';
    this.message = 'New User Registration completed !';
  }
  confirmMsg() {
    this.heading = 'Confirm Message';
    this.message = 'Are you sure want to delete?';
  }

}
