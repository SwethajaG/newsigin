import { Component, DoCheck } from '@angular/core';
import { UserService } from './services/user.service';
import { Router } from '@angular/router';
import { StudentService } from './services/student.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements DoCheck {
  title = 'signin';
  isHome = false;
  studentsLength = 0;
  staffName = '';

  isLogined = this.userService.userName === '' ? false : true;
  constructor(private userService: UserService, private studentService: StudentService, private router: Router) {
    //this.router.navigate(['/signin']);
    this.getBasicDetails();
  }
  ngDoCheck(): void {
    if (this.router.url === '/') {
      this.isHome = true;
    }else{
      this.isHome = false;
    }
    this.studentsLength = this.studentService.studentsLength;
    this.staffName = this.userService.userName;
    this.isLogined = this.userService.userName === '' ? false : true;
   // this.isHome = this.userService.userName === '' ? false : true;
  }
  getBasicDetails() {
    this.studentService.getAllStudents().subscribe((data: any) => {
      this.studentService.studentsLength = data.length;
    });
  }
}
